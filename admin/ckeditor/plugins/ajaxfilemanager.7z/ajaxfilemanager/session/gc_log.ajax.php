<?php die(); ?>
gc start at 01/Jul/2012 14:58:51

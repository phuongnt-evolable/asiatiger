<pre>Array
(
    [currentFolderPath] => ../../../../img/product/detail/News/
    [new_folder] => 20120701 Hang moi ve
)
</pre>

01/Jul/2012 11:13:28